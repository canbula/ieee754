from ieee754.IEEE754 import IEEE754
from ieee754.IEEE754 import half
from ieee754.IEEE754 import single
from ieee754.IEEE754 import double
from ieee754.IEEE754 import quadruple
from ieee754.IEEE754 import octuple
